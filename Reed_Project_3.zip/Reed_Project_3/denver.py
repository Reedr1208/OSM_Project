import xml.etree.cElementTree as ET
import pprint
import collections as col
import re
import cerberus
import schema
import csv
import codecs
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

file= 'denver-boulder_colorado.osm'
#file_size= 739.4MB
#file = 'sample.osm'


#defining a function to count the number of occurances of each unique tag
#in the entire xml file
#only 'ways' and nodes (and their associated children tags) will be included in the database
def count_tags(filename):
	tags= col.defaultdict(int)
	for event, elem in ET.iterparse(filename):
		tags[elem.tag]+=1
	return tags

#pprint.pprint( dict(count_tags(file)))



#_______________________________________________________________
#'tag' elements contain keys and values as attributes of the element
#count the total number of keys for 3 different formats

#lower= match keys containing only lowercase letters or underscores
lower = re.compile(r'^([a-z]|_)*$')

#lower_colon= match keys containing only lower case letters or underscores, along with a single colon
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')

#problemchars= match keys containing = + / & < > ; ' " ? % # $ @ , . or whitespace characters
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')

#to be called by process_map function
def key_type(element, keys):
	if element.tag == "tag":
		tag_key= element.attrib['k']
		
		if lower.search(tag_key):
			keys['lower']+=1
		elif lower_colon.search(tag_key):
			keys['lower_colon']+=1
		elif problemchars.search(tag_key):
			keys['problemchars']+=1
		else:
			keys['other']+=1
	return keys

	
""" 
In full data file, all 'problemchars' keys contained whitespaces, periods, or slash marks.

'other' keys contained:
-capital letters
-multiple colons
-numbers
"""

#return a dict with count of the number of keys satisfying each of the regex's defined earlier
def process_key_names(filename):
	keys = {"lower": 0, "lower_colon": 0, "problemchars": 0, "other": 0}
	for _, element in ET.iterparse(filename):
		keys = key_type(element, keys)

	return keys

#print process_key_names(file)




#get the last word of a street name. This last word will be referred to as the 'street type'
street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)

#These are the expected street types
expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", 
            "Trail", "Parkway", "Commons", "Circle", "Point", "Way"]

#Keys are the street types to be replaced by their associated values
mapping = { "St": "Street",
            "St.": "Street",
			"STreet": "Street",
			"Strret": "Street",
            "Ave": "Avenue",
			"Ave.": "Avenue",
            "Rd.": "Road",
			"Rd": "Road",
			"rd": "Road",
			"circle": "Circle",
			"Cir": "Circle",
			"Pkwy": "Parkway",
			"Pky": "Parkway",
			"dr": "Drive",
			"Pl": "Place",
			"Ct": "Court",
			"ct": "Court",
			"Blvd": "Boulevard"
            }


#Below is a dict to be used to clean bank names			
#keys are regular expressions to be searched for in bank names
#values are the new bank names if the search function returns a result
#most of the reg expressions behave like the 'startswith' function when searched
regex_bank_dict= { 
'^(1st|First)\s*Bank': 'FirstBank',
'^Bank of the West':'Bank of the West',
'belco|bellco|bello': 'Bellco Credit Union',
'^BBVA': 'BBVA Compass',
'^Chase': 'Chase Bank',
'^Citywide': 'Citywide Banks',
'^Colorado State Bank': 'Colorado State Bank and Trust',
'^Community Bank': 'Community Banks of Colorado',
'^Guar': 'Guaranty Bank and Trust Company',
'^Key': 'KeyBank',
'^Mutual': 'Mutual of Omaha Bank',
'^Public Service': 'Public Service Credit Union',
'^Security Service': 'Security Service Federal Credit Union',
'^U\.*S\.*\s*Bank': 'U.S. Bank',
'^UMB': 'UMB Bank',
'^Valley': 'Valley Bank & Trust',
'^Wells': 'Wells Fargo Bank'
}

#Some restaurants occur as joint businesses such as 'Pizza Hut & Wing Street'
#This dictionary is used to match only the restaurants which frequently occur as joint businesses
#Key are the regular expressions matching these restuarants
#Values are the standard restaurant name to replaced the matched regex with
food_doubles= {
'A\s*&\s*W': 'A&W',
'KFC': 'KFC',
'Long John Silver': "Long John Silver's",
"Carl's": "Carl's Jr.",
'Green Burrito': 'Green Burrito',
'Dairy Queen|DQ': 'Dairy Queen',
'Orange (Julius|Juilius)': 'Orange Julius',
'Pizza Hut': 'Pizza Hut',
'Taco Bell': 'Taco Bell',
'Wing Street': 'Wing Street',
'Subway': 'Subway'
}

#Dict used to replace the rest of the restaurants with a standard name
#Keys are regular expressions matching fast food restuarants which need cleaning
#Values are cleaned restaurant names
food_regex= {
'Grab and Go': 'Grab and Go',
"^Arby's": "Arby's",
'^Black\s*Jack': 'Blackjack Pizza',
'^Chick|Chik': 'Chick-fil-A',
'^Chipotle': 'Chipotle Mexican Grill',
'^Church': "Church's Chicken",
'^Cold Stone': 'Cold Stone Creamery',
'^Cosmo': 'Cosmos Frozen Yogurt',
'^Domino': "Domino's Pizza",
'^Einstein': 'Einstein Bros. Bagels',
'^Fazoli': "Fazoli's",
'^Five Guys': 'Five Guys Burgers and Fries',
'^Food Court': 'Food Court',
"^Freddy's": "Freddy's Frozen Custard & Steakburgers",
'^Good\s*Times': 'Good Times Burgers & Frozen Custard',
"^Heidi's": "Heidi's Brooklyn Deli",
'^Jack': 'Jack in the Box',
"^Jersey Mike's": "Jersey Mike's Subs",
'^Jimmy': "Jimmy John's",
'^Krispy': 'Krispy Kreme',
"^Little": "Little Caesars Pizza",
"^Marco": "Marco's Pizza",
"^Noodles": "Noodles & Company",
"^Papa John": "Papa John's Pizza",
"^Papa Murphy": "Papa Murphy's Take 'N' Bake Pizza",
"^Popeye's": "Popeyes Louisiana Kitchen",
"^Qdoba": "Qdoba Mexican Eats",
"^Quizno": "Quiznos",
"^Salvaggio's": "Salvaggio's Deli",
"^Smashburger": "Smashburger",
"^Sonic": "Sonic Drive-In",
"^Tokyo": "Tokyo Joe's",
"^Wahoo's": "Wahoo's Fish Taco"
}

#takes old bank name as argument
#uses regex_bank_dict  to replace bank name
#If more than one regex expression matches the old bank name, an error is raised
def clean_bank_name(bank):
	match_counter=0
	new_bank_name= bank
	for k, v in regex_bank_dict.items():
		if re.search(k, bank, re.IGNORECASE):
			new_bank_name= v
			match_counter+=1
		else:
			pass
	if match_counter>1:
		raise ValueError('More than one regex matched the old bank name')
	return new_bank_name

#Takes human-inputted name of restaurant and returns clean name
#Function first checks for joint businesses and reformats the restaurant names with food_doubles dict if a match is found
#Function then uses food_regex to update other names which need cleaning
#and error is raised is more than one match is found for non-joint businesses
def clean_fast_food(name):
	food_counter=0
	shared_restaurant_list=[]
	for k, v in food_doubles.items():
		if re.search(k, name, re.IGNORECASE):
			food_counter+=1
			shared_restaurant_list.append(v)
	if len(shared_restaurant_list)>0:
		new_food_name= (' / '.join(sorted(shared_restaurant_list)))
	else:
		match_counter=0
		new_food_name= name
		for k, v in food_regex.items():
			if re.search(k, name, re.IGNORECASE):
				new_food_name= v
				match_counter+=1
			else:
				pass
		if match_counter>1:
			raise ValueError('More than one regex matched the old fast_food name')		
	return new_food_name




			


#this function is called by 'audit'
#street_name variable will be passed by the audit function. it is the value attribute in the 'tag' element for street name keys
#street types is a dictionary of sets initialized in 'audit'
#keys will be the street type (last word in street name) and values with will be every street name ending with that street type
#Thid dictionary will only contain keys that ARE NOT in the 'expected' list
def audit_street_type(street_types, street_name):
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)

#takes a <tag> as an argument and checks if its k attribute is 'addr:street' (indicating a street name as a v attribute)
#returns a boolean
def is_street_name(elem):
    return (elem.attrib['k'] == "addr:street")

#takes a node element as argument
#checks if that node element contains a <tag> with 'amenity' as its k attribute and 'bank' as its v attribute
#then checks if that node also contains a <tag> element with the bank name as an attribute
#Returns true if the node contains a bank name
def is_bank_node(node):
	hit= node.find("./tag[@k='amenity'][@v='bank']/../tag[@k='name']")
	if hit is not None:
		return True
	else:
		return False


#takes a node element as argument
#checks if that node element contains a <tag> with 'amenity' as its k attribute and 'fast_food' as its v attribute
#then checks if that node also contains a <tag> element with the fast_food name as an attribute
#Returns True if the node contains a fast_food name
def is_fast_food_node(node):
	hit= node.find("./tag[@k='amenity'][@v='fast_food']/../tag[@k='name']")
	if hit is not None:
		return True
	else:
		return False

#function used to group street names that are not contained by our expected street types
#initializes a dict of sets. 
#Keys will be street types (last word in street name) Values will be sets of street names of that street type
#Only looks at the tags of nodes or ways
def audit(osmfile):
	osm_file = codecs.open(osmfile, "r")
	street_types = col.defaultdict(set)
	for event, elem in ET.iterparse(osm_file, events=("start",)):

		if elem.tag == "node" or elem.tag == "way":
			for tag in elem.iter("tag"):
				if is_street_name(tag):
					audit_street_type(street_types, tag.attrib['v'])
	osm_file.close()
	return street_types

#Use 'mapping' dict to update street names with new street types
#This function will be used when writing street names to csv file
def update_name(name, mapping):
	if street_type_re.search(name) is None:
		return name
	else:
		old_street_type= street_type_re.search(name).group()
		if old_street_type in mapping.keys():
			new_street_type= mapping[old_street_type]
			name= name.replace(old_street_type, new_street_type)
		return name



#uncomment to view the street_types dict to assist in building the mapping dict
"""
for k, v in audit(file).items():
	print k, v, '\n'
"""
	
	
#_______________________________________________________________

#Shape the data appropriately and export as csv files


OSM_PATH = file

#Change path to desired directory
BASE_PATH= 'C:\Users\Reedr\Desktop\osm_tables\\'

#these are files to be written to
NODES_PATH = BASE_PATH + "nodes.csv"
NODE_TAGS_PATH = BASE_PATH + "nodes_tags.csv"
WAYS_PATH = BASE_PATH + "ways.csv"
WAY_NODES_PATH = BASE_PATH + "ways_nodes.csv"
WAY_TAGS_PATH = BASE_PATH + "ways_tags.csv"

#anything in the proper lowercase format with one colon
LOWER_COLON = re.compile(r'^([a-z]|_)+:([a-z]|_)+')

#any problem chars as described earlier
PROBLEMCHARS = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')

#something from schema library. Not sure how it works
#a file schema.py was used in the udacity code
SCHEMA = schema.schema

#These are the fields to be included in our reformatted data
NODE_FIELDS = ['id', 'lat', 'lon', 'user', 'uid', 'version', 'changeset', 'timestamp']
NODE_TAGS_FIELDS = ['id', 'key', 'value', 'type']
WAY_FIELDS = ['id', 'user', 'uid', 'version', 'changeset', 'timestamp']
WAY_TAGS_FIELDS = ['id', 'key', 'value', 'type']
WAY_NODES_FIELDS = ['id', 'node_id', 'position']


#This will put the xml data in the shape we need for exporting
#Street names, bank names, and fast food restaurant names are cleaned in this stage
def shape_element(element, node_attr_fields=NODE_FIELDS, way_attr_fields=WAY_FIELDS, problem_chars=PROBLEMCHARS, default_tag_type='regular'):
	"""Clean and shape node or way XML element to Python dict"""
	node_attribs = {}
	way_attribs = {}
	way_nodes = []
	tags = []  # Handle secondary tags the same way for both node and way elements


	if element.tag == 'node':
		for i in node_attr_fields:
			node_attribs[i]= element.attrib[i]
		
		#each <tag> within the <node>
		for i in element:
			#if the key attribute of the <tag> has problem characters, dont even include that <tag> in the database
			if re.search(PROBLEMCHARS, i.attrib['k']):
					continue
			#tag_dict is creating for each individaul <tag>
			tag_dict= {}
			#give the tag the same ID as the node
			tag_dict['id']= element.attrib['id']
			if re.search(LOWER_COLON, i.attrib['k']):
					#clean the key according to udacity directions
					tag_dict['key']= ':'.join(i.attrib['k'].split(':')[1:])
					tag_dict['type']= i.attrib['k'].split(':')[0]
			else:
				#if no colons involved, tag dict key is just the <tag>'s 'k' attribute value
				tag_dict['key']= i.attrib['k']
				tag_dict['type']='regular'
			
			#if <tag> is a street name, clean that name before adding it to tag_dict
			if is_street_name(i):
				tag_dict['value']= update_name(name=i.attrib['v'], mapping=mapping)
			
			#if <tag> is a fast food restaurant name, clean it before adding it to tag_dict
			elif is_fast_food_node(element) and i.attrib['k']=='name':
				tag_dict['value']= clean_fast_food(name= i.attrib['v'])
			
			#if <tag> is a bank name, clean that bank name before adding it to tag_dict
			elif i.attrib['k']=='name' and is_bank_node(element):
				tag_dict['value']= clean_bank_name(bank= i.attrib['v'])
			
			else:
				tag_dict['value']= i.attrib['v']
			tags.append(tag_dict)

		return {'node': node_attribs, 'node_tags': tags}




	elif element.tag == 'way':
		for i in way_attr_fields:
			way_attribs[i]=element.attrib[i]
		position_counter=0
		for nd in element:
			way_nodes_dict={}
			if nd.tag=='nd':
				way_nodes_dict['id']= element.attrib['id']
				way_nodes_dict['node_id']= nd.attrib['ref']
				way_nodes_dict['position']= position_counter
				position_counter+=1
				way_nodes.append(way_nodes_dict)
			
			if nd.tag== 'tag':
				if re.search(PROBLEMCHARS, nd.attrib['k']):
					continue
				tag_dict={}
				tag_dict['id']= element.attrib['id']
				tag_dict['value']= nd.attrib['v']
				
				if re.search(LOWER_COLON, nd.attrib['k']):
					tag_dict['key']= ':'.join(nd.attrib['k'].split(':')[1:])
					tag_dict['type']= nd.attrib['k'].split(':')[0]
				else:
					tag_dict['key']= nd.attrib['k']
					tag_dict['type']= 'regular'
					
				
				tags.append(tag_dict)
		return {'way': way_attribs, 'way_nodes': way_nodes, 'way_tags': tags}


def get_element(osm_file, tags=('node', 'way', 'relation')):
    """Yield element if it is the right type of tag"""

    context = ET.iterparse(osm_file, events=('start', 'end'))
    _, root = next(context)
    for event, elem in context:
        if event == 'end' and elem.tag in tags:
            yield elem
            root.clear()


def validate_element(element, validator, schema=SCHEMA):
    """Raise ValidationError if element does not match schema"""
    if validator.validate(element, schema) is not True:
        field, errors = next(validator.errors.iteritems())
        message_string = "\nElement of type '{0}' has the following errors:\n{1}"
        error_strings = (
            "{0}: {1}".format(k, v if isinstance(v, str) else ", ".join(v))
            for k, v in errors.iteritems()
        )
        raise cerberus.ValidationError(
            message_string.format(field, "\n".join(error_strings))
        )


class UnicodeDictWriter(csv.DictWriter, object):
    """Extend csv.DictWriter to handle Unicode input"""

    def writerow(self, row):
        super(UnicodeDictWriter, self).writerow({
            k: (v.encode('utf-8') if isinstance(v, unicode) else v) for k, v in row.iteritems()
        })

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)


# ================================================== #
#               Main Function                        #
# ================================================== #

#Set up each of the 5 csv files to be written to. These will be used to construct a database
def process_map(file_in, validate):
	"""Iteratively process each XML element and write to csv(s)"""

	with codecs.open(NODES_PATH, 'w') as nodes_file, \
		 codecs.open(NODE_TAGS_PATH, 'w') as nodes_tags_file, \
		 codecs.open(WAYS_PATH, 'w') as ways_file, \
		 codecs.open(WAY_NODES_PATH, 'w') as way_nodes_file, \
		 codecs.open(WAY_TAGS_PATH, 'w') as way_tags_file:

		nodes_writer = UnicodeDictWriter(nodes_file, NODE_FIELDS, lineterminator='\n')
		node_tags_writer = UnicodeDictWriter(nodes_tags_file, NODE_TAGS_FIELDS, lineterminator='\n')
		ways_writer = UnicodeDictWriter(ways_file, WAY_FIELDS, lineterminator='\n')
		way_nodes_writer = UnicodeDictWriter(way_nodes_file, WAY_NODES_FIELDS, lineterminator='\n')
		way_tags_writer = UnicodeDictWriter(way_tags_file, WAY_TAGS_FIELDS, lineterminator='\n')


		nodes_writer.writeheader()
		node_tags_writer.writeheader()
		ways_writer.writeheader()
		way_nodes_writer.writeheader()
		way_tags_writer.writeheader()

		validator = cerberus.Validator()

		#for each element in xml file clean and format the data using the 'shape_element' function
		#and write the data to the approprite csv file
		#Also use the schema file to validate each reshaped element before adding it
		for element in get_element(file_in, tags=('node', 'way')):
			el = shape_element(element)
			if el:
				if validate is True:
					validate_element(el, validator)

				if element.tag == 'node':
					nodes_writer.writerow(el['node'])
					node_tags_writer.writerows(el['node_tags'])
				elif element.tag == 'way':
					ways_writer.writerow(el['way'])
					way_nodes_writer.writerows(el['way_nodes'])
					way_tags_writer.writerows(el['way_tags'])

	

#print out each type of amenity and the number of occurances of that amenity type on the map
#This is used to find valid arguments for the next function (named_amenity_list)
def find_amenity_types():
	amenity_dict=col.defaultdict(int)
	osm_file = codecs.open(file, "r")
	for event, elem in ET.iterparse(osm_file, events=("start",)):
		if elem.tag == "node":
			for tag in elem.iter("tag"):
				if tag.attrib['k']=='amenity':
					amenity_dict[tag.attrib['v']]+=1
	for k, v in amenity_dict.items():
		print k, v

#find_amenity_types()	
	
	

#Print a sorted list of the names of all amenities of a certain type				
#amenity type includes categories such as fuel, fast_food, bank etc
#This function was used to find inconsistencies in human inputted amenity names to be cleaned
def named_amenity_list(amenity_type):
	amenity_list= set()
	osm_file = codecs.open(file, "r")
	for event, elem in ET.iterparse(osm_file, events=("start",)):

		if elem.tag == "node":
			for tag in elem.iter("tag"):
				if tag.attrib['k']=='amenity' and tag.attrib['v']==amenity_type:
					for tag2 in elem.iter('tag'):
						if tag2.attrib['k']=='name':
							amenity_list.add(tag2.attrib['v'])

	amenity_list= sorted(list(amenity_list))
	print'\n'
	for i in amenity_list:
		print i
	return

#named_amenity_list('fast_food')
#named_amenity_list('bank')




#process_map(OSM_PATH, validate=True)	


