from __future__ import division
import sqlite3
import csv
from pprint import pprint
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.basemap import Basemap
import numpy as np

#load csv into db

sqlite_file= 'Denver.db'
conn= sqlite3.connect(sqlite_file)
conn.text_factory= str
cur= conn.cursor()


"""
BASE_PATH= 'C:\Users\Reedr\Desktop\osm_tables\\'   #< to tables

cur.execute('''CREATE TABLE nodes(id INTEGER Primary Key, lat REAL, lon REAL, user TEXT, uid INTEGER, version INTEGER, changeset INTEGER, timestamp TEXT)''')
cur.execute('''CREATE TABLE nodes_tags(id INTEGER, key TEXT, value TEXT, type TEXT, PRIMARY KEY(id, key, type))''')
cur.execute('''CREATE TABLE ways(id INTEGER Primary Key, user TEXT, uid INTEGER, version INTEGER, changeset INTEGER, timestamp TEXT)''')
cur.execute('''CREATE TABLE ways_nodes(id INTEGER, node_id INTEGER, position INTEGER)''')
cur.execute('''CREATE TABLE ways_tags(id INTEGER, key TEXT, value TEXT, type TEXT, PRIMARY KEY (id, key, type))''')

conn.commit()

f_nodes= open(BASE_PATH+'nodes.csv', 'rb')
f_nodes_tags= open(BASE_PATH+'nodes_tags.csv', 'rb')
f_ways= open(BASE_PATH+'ways.csv', 'rb')
f_ways_nodes= open(BASE_PATH+'ways_nodes.csv', 'rb')
f_ways_tags= open(BASE_PATH+'ways_tags.csv', 'rb')

#Populate the nodes table
dr= csv.DictReader(f_nodes)
to_db= [(i['id'], i['lat'],i['lon'], i['user'], i['uid'], i['version'], i['changeset'], i['timestamp']) for i in dr]
cur.executemany("INSERT INTO nodes(id, lat, lon, user, uid, version, changeset, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?);", to_db)
conn.commit()

#Populate the nodes_tags table
dr= csv.DictReader(f_nodes_tags)
to_db= [(i['id'], i['key'], i['value'], i['type']) for i in dr]
cur.executemany("INSERT INTO nodes_tags(id, key, value, type) VALUES (?, ?, ?, ?);", to_db)
conn.commit()

#Populate the ways table
dr= csv.DictReader(f_ways)
to_db= [(i['id'], i['user'],i['uid'], i['version'], i['changeset'], i['timestamp']) for i in dr]
cur.executemany("INSERT INTO ways(id, user, uid, version, changeset, timestamp) VALUES (?, ?, ?, ?, ?, ?);", to_db)
conn.commit()

#Populate the ways_nodes table
dr= csv.DictReader(f_ways_nodes)
to_db= [(i['id'], i['node_id'],i['position']) for i in dr]
cur.executemany("INSERT INTO ways_nodes(id, node_id, position) VALUES (?, ?, ?);", to_db)
conn.commit()

#Populate the ways_tags table
dr= csv.DictReader(f_ways_tags)
to_db= [(i['id'], i['key'],i['value'], i['type']) for i in dr]
cur.executemany("INSERT INTO ways_tags(id, key, value, type) VALUES (?, ?, ?, ?);", to_db)
conn.commit()
"""


#Finding duplicate id/key rows
"""
#For the nodes_tags table, the id & key columns couldn't be used as the primary keys since this set of paired values is not unique
#This query will select rows from nodes_tags which do not have unique id/key pairs
#We find that these rows will be unique when the 'type' value is included 
cur.execute('''SELECT nodes_tags.id, nodes_tags.key, nodes_tags.value, nodes_tags.type 
	FROM (SELECT id, key, num, type 
		FROM (SELECT id, key, COUNT(*) as num, type 
			FROM nodes_tags GROUP BY id, key, value ORDER BY num) 
			WHERE num>1) as table_2 
		LEFT JOIN nodes_tags on table_2.id=nodes_tags.id AND table_2.key=nodes_tags.key''')


rows= cur.fetchall()
pprint (rows)
"""


def query_fast_food():
	#Find total restaurants, named restaurants, and proportion of named restaurants

	cur.execute('''
	SELECT COUNT(*)
	FROM nodes_tags
	WHERE key="amenity" AND value= "fast_food"
	''')
	total_restaurants= cur.fetchall()[0][0]


	cur.execute('''
	SELECT COUNT(*) 
	FROM nodes_tags JOIN (
		SELECT id 
		FROM nodes_tags 
		WHERE key="amenity" AND VALUE="fast_food") as ff_nodes 
		ON nodes_tags.id=ff_nodes.id 
	WHERE nodes_tags.key="name"
	''')
	named_restaurants= cur.fetchall()[0][0]

	print 'Total number of fast food restaurants: {}\n\
Total number of named restaurants: {}\n\
Proportion of fast food restaurants with names: {}\n'.format(total_restaurants, named_restaurants, round(named_restaurants/total_restaurants, 2))





	#Find the top 10 most most common fast food restaurants in Denver/Bouler
	#And the number of distinct ff restaurants

	cur.execute('''
	SELECT nodes_tags.value, COUNT(*) as num 
	FROM nodes_tags JOIN (
		SELECT id 
		FROM nodes_tags 
		WHERE key="amenity" AND VALUE="fast_food") as ff_nodes 
		ON nodes_tags.id=ff_nodes.id 
	WHERE nodes_tags.key="name"
	GROUP BY nodes_tags.value
	ORDER BY num DESC
	LIMIT 10
	''')
	rows= cur.fetchall()
	pprint (rows)




	#Number of distinct fast_food restaurants
	#Note that a unique pair of restaurants (ex. 'Pizza Hut / Wing Street') will be counted in this tally
	cur.execute('''
	SELECT COUNT(DISTINCT nodes_tags.value) 
	FROM nodes_tags JOIN (
		SELECT id 
		FROM nodes_tags 
		WHERE key="amenity" AND VALUE="fast_food") as ff_nodes 
		ON nodes_tags.id=ff_nodes.id 
	WHERE nodes_tags.key="name"
	''')
	num_distinct= cur.fetchall()[0][0]
	print 'Number of distinct fast-food restaurants: {}'.format(num_distinct)
	return

#query_fast_food()




#_______________________________________________________________________
#Query the banks
def query_banks():
	print'\n\n'
	cur.execute('''
	SELECT COUNT(*)
	FROM nodes_tags
	WHERE key="amenity" AND value= "bank"
	''')
	total_banks= cur.fetchall()[0][0]

	cur.execute('''
	SELECT COUNT(*) 
	FROM nodes_tags JOIN (
		SELECT id 
		FROM nodes_tags 
		WHERE key="amenity" AND VALUE="bank") as bank_nodes 
		ON nodes_tags.id=bank_nodes.id 
	WHERE nodes_tags.key="name"
	''')
	named_banks= cur.fetchall()[0][0]

	print 'Total number of banks: {}\n\
Total number of named banks: {}\n\
Proportion of banks with names: {}\n'.format(total_banks, named_banks, round(named_banks/total_banks, 2))



	#Find most common banks
	cur.execute('''
	SELECT nodes_tags.value, COUNT(*) as num 
	FROM nodes_tags JOIN (
		SELECT id 
		FROM nodes_tags 
		WHERE key="amenity" AND VALUE="bank") as bank_nodes 
		ON nodes_tags.id=bank_nodes.id 
	WHERE nodes_tags.key="name"
	GROUP BY nodes_tags.value
	ORDER BY num DESC
	LIMIT 10
	''')
	rows= cur.fetchall()
	pprint (rows)


	#Number of distinct banks
	cur.execute('''
	SELECT COUNT(DISTINCT nodes_tags.value) 
	FROM nodes_tags JOIN (
		SELECT id 
		FROM nodes_tags 
		WHERE key="amenity" AND VALUE="bank") as bank_nodes 
		ON nodes_tags.id=bank_nodes.id 
	WHERE nodes_tags.key="name"
	''')
	num_distinct= cur.fetchall()[0][0]
	print
	print 'Number of distinct banks: {}'.format(num_distinct)
	return

#query_banks()


def plot_entries_by_year():
	cur.execute('''
	SELECT nodes.timestamp FROM nodes
	UNION ALL
	SELECT ways.timestamp FROM ways
	''')
	rows= cur.fetchall()

	edits_by_year= defaultdict(int)
	for i in rows:
		edits_by_year[int(i[0][0:4])]+=1

	years=sorted(edits_by_year.keys())
	print edits_by_year
	edits= []
	for i in years:
		edits.append(edits_by_year[i])

	plt.title('Number of Entries/Updates by Year')
	plt.ylabel('Number of Entries/Updates')
	plt.xlabel('Year')
	plt.bar(years, edits, align='center')
	plt.xticks(years)
	#plt.axis([2007, 2016, 0, 1000000])
	#plt.ticklabel_format(useOffset=False)

	plt.show()
	return

#plot_entries_by_year()


top_3_ff_coordinates={"Subway_lats":[], "Subway_lons":[], "McDonald's_lats":[], "McDonald's_lons":[], "Taco_Bell_lats":[], "Taco_Bell_lons":[]}


#creating map of top 3 fast food restaurants

def add_to_coordinate_dict(ff_name, lat_key, lon_key):
	restaurant_coordinates= '''
	SELECT nodes.id, nodes.lat, nodes.lon, restaurant_list.value
	FROM nodes JOIN
		(SELECT nodes_tags.id, nodes_tags.value
		FROM nodes_tags JOIN
			(SELECT nodes_tags.id
			FROM nodes_tags
			WHERE key='amenity' AND value='fast_food') as ff_tags
		ON nodes_tags.id=ff_tags.id
		WHERE nodes_tags.key='name' AND nodes_tags.value="{}") as restaurant_list
	ON nodes.id=restaurant_list.id
	'''.format(ff_name)


	cur.execute(restaurant_coordinates)
	rows= cur.fetchall()

	lats=[]
	lons=[]
	for i in rows:
		lats.append(i[1])
		lons.append(i[2])
	top_3_ff_coordinates[lat_key]= lats
	top_3_ff_coordinates[lon_key]= lons
	return

def create_fast_food_maps():
	add_to_coordinate_dict(ff_name="Subway", lat_key="Subway_lats", lon_key="Subway_lons")	
	add_to_coordinate_dict(ff_name="McDonald's", lat_key="McDonald's_lats", lon_key="McDonald's_lons")
	add_to_coordinate_dict(ff_name="Taco Bell", lat_key="Taco_Bell_lats", lon_key="Taco_Bell_lons")

	map = Basemap(llcrnrlon=-105.3973,
				llcrnrlat=39.4553,
				urcrnrlon=-104.5789,
				urcrnrlat=40.1264, epsg=4269)


	map.arcgisimage(service='ESRI_StreetMap_World_2D', xpixels = 1000, verbose= True)

	marker_size=9
	map.plot(top_3_ff_coordinates["Subway_lons"], top_3_ff_coordinates["Subway_lats"], 'ro', markersize= marker_size, latlon=True, label='Subway')
	map.plot(top_3_ff_coordinates["McDonald's_lons"], top_3_ff_coordinates["McDonald's_lats"], 'g^', markersize= marker_size, latlon=True, label="McDonald's")
	map.plot(top_3_ff_coordinates["Taco_Bell_lons"], top_3_ff_coordinates["Taco_Bell_lats"], 'bs', markersize= marker_size, latlon=True, label="Taco Bell")


	plt.title('Top 3 Most Common Fast-Food Restaurants', fontdict={'weight':'bold', 'size':'20'})
	plt.legend(loc='upper right', frameon=True, prop={'weight':'bold', 'size':'16'}).draggable()
	plt.show()


	all_restaurant_coordinates= '''
	SELECT nodes.id, nodes.lat, nodes.lon, restaurant_list.value
	FROM nodes JOIN
		(SELECT nodes_tags.id, nodes_tags.value
		FROM nodes_tags JOIN
			(SELECT nodes_tags.id
			FROM nodes_tags
			WHERE key='amenity' AND value='fast_food') as ff_tags
		ON nodes_tags.id=ff_tags.id
		WHERE nodes_tags.key='name') as restaurant_list
	ON nodes.id=restaurant_list.id
	'''
	cur.execute(all_restaurant_coordinates)
	rows= cur.fetchall()

	all_lats=[i[1] for i in rows]
	all_lons=[i[2] for i in rows]

	map.arcgisimage(service='ESRI_StreetMap_World_2D', xpixels = 1000, verbose= True)
	map.plot(all_lons, all_lats, 'mo', markersize= 9, latlon=True, label='Subway')
	plt.title('All Fast-Food Restaurant Locations', fontdict={'weight':'bold', 'size':'20'})
	plt.show()
	return

#create_fast_food_maps()

def query_users():
	users_query="""
	SELECT users.user, COUNT(*) as num 
	FROM
		(SELECT user, uid FROM nodes
		UNION ALL
		SELECT user, uid FROM ways) as users
	GROUP BY users.user
	ORDER BY num DESC
	LIMIT 10
	"""
	cur.execute(users_query)
	rows=cur.fetchall()
	print 'Top ten most contributing users: \n'
	pprint(rows)
	
	
	average_contributions_query="""
	SELECT AVG(contributions.num)
	FROM
		(SELECT users.user, COUNT(*) as num 
		FROM
			(SELECT user, uid FROM nodes
			UNION ALL
			SELECT user, uid FROM ways) as users
		GROUP BY users.user) as contributions
	"""
	cur.execute(average_contributions_query)
	rows=cur.fetchall()
	print '\nAverage number of entires per user: {}'.format(rows[0][0])

	unique_users_query="""
	SELECT COUNT(DISTINCT users.uid) as num
	FROM
		(SELECT user, uid FROM nodes
		UNION
		SELECT user, uid FROM ways) as users
	"""
	cur.execute(unique_users_query)
	rows=cur.fetchall()
	print '\nNumber of unique users: {}'.format(rows[0][0])
	return

#query_users()

def query_ways_and_nodes():
	num_nodes_query="""
	SELECT COUNT(*)
	FROM nodes
	"""
	cur.execute(num_nodes_query)
	rows=cur.fetchall()
	num_nodes=rows[0][0]
	print '\nNumber of nodes: {}'.format(num_nodes)

	num_ways_query="""
	SELECT COUNT(*)
	FROM ways
	"""
	cur.execute(num_ways_query)
	rows=cur.fetchall()
	num_ways= rows[0][0]
	print '\nNumber of ways: {}'.format(num_ways)

	total_entries= num_nodes+num_ways
	print '\nTotal number of entries: {}'.format(total_entries)

	entries_from_top_contributors_query="""
	SELECT SUM(top.num)
	FROM
		(SELECT users.user, COUNT(*) as num 
		FROM
			(SELECT user, uid FROM nodes
			UNION ALL
			SELECT user, uid FROM ways) as users
		GROUP BY users.user
		ORDER BY num DESC
		LIMIT 10) as top
	"""
	cur.execute(entries_from_top_contributors_query)
	rows=cur.fetchall()
	entries_by_top_ten=rows[0][0]

	print '\nTotal number of entries by top 10 contributors: {}'.format(entries_by_top_ten)
	print '\nPercentage of contributions from top 10 contributors: {}'.format(entries_by_top_ten/total_entries)
	return

#query_ways_and_nodes()	



#query_fast_food()
#query_banks()
#plot_entries_by_year()
#create_fast_food_maps()
#query_users()
#query_ways_and_nodes()


conn.close()

